<?php
session_start();
require_once 'EasyPDO.php';

use EasyPDO\EasyPDO;

// Verificar se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Configurações do banco de dados
$dbConfig = [
    'db_host' => 'localhost',
    'db_name' => 'aceagrarios',
    'db_user' => 'Clinton',
    'db_pass' => 'zU1NP5[XIUmJ5aK1'
];

// Inicializar EasyPDO
$query = new EasyPDO($dbConfig);

// Buscar informações do usuário
$user_id = $_SESSION['user_id'];


try {
    // Buscar informações do usuário
    $user = $query->select("SELECT nome, foto_perfil FROM usuarios WHERE id = :id", ['id' => $user_id]);
    $user = $user[0] ?? null;

    // Buscar as 10 publicações mais recentes
    $publicacoes = $query->select("
    SELECT p.*, u.nome as autor, u.foto_perfil 
    FROM publicacoes p 
    JOIN usuarios u ON p.user_id = u.id 
    ORDER BY p.data_criacao DESC 
    LIMIT 10
");
    // Processar nova publicação
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['publicar'])) {
        $conteudo = $_POST['conteudo'];
        $dataHoraAtual = date('Y-m-d H:i:s');
        $arquivos_midia = [];

        // Processar múltiplos uploads de arquivos (imagens e vídeos)
        if (!empty($_FILES['midia']['name'][0])) {
            foreach ($_FILES['midia']['tmp_name'] as $key => $tmp_name) {
                $arquivo_nome = $_FILES['midia']['name'][$key];
                $arquivo_tipo = $_FILES['midia']['type'][$key];

                // Gerar o caminho para salvar o arquivo no servidor
                $destino_arquivo = 'uploads/' . basename($arquivo_nome);

                // Mover o arquivo para a pasta de uploads
                if (move_uploaded_file($tmp_name, $destino_arquivo)) {
                    // Armazenar a URL do arquivo na array
                    $arquivos_midia[] = $destino_arquivo;
                }
            }
        }

        // Converte o array de URLs em uma string separada por vírgulas
        if (!empty($arquivos_midia)) {
            $midia_urls = implode(',', $arquivos_midia);
        } else {
            $midia_urls = null;  // Nenhum arquivo foi carregado
        }

        // Inserir a nova publicação no banco de dados
        $inserted = $query->insert("INSERT INTO publicacoes (user_id, conteudo, media_urls, data_criacao, data_atualizacao) VALUES (:user_id, :conteudo, :media_urls, :data_criacao, :data_atualizacao)", [
            'user_id' => $user_id,
            'conteudo' => $conteudo,
            'media_urls' => $midia_urls,  // Corrigido para usar $midia_urls
            'data_criacao' => $dataHoraAtual,
            'data_atualizacao' => $dataHoraAtual
        ]);

        // Redirecionar após a publicação
        header("Location: index.php");
        exit();
    }
} catch (Exception $e) {
    die("Erro ao buscar dados: " . $e->getMessage());
}



// Listar conversas e usuários
try {
    $conversas = $query->select("
        SELECT u.id, u.nome 
        FROM conversas c
        JOIN usuarios u ON c.user2_id = u.id
        WHERE c.user1_id = :user1_id
        GROUP BY u.id, u.nome
    ", ['user1_id' => $user_id]);

    $usuarios = $query->select("SELECT id, nome FROM usuarios WHERE id != :user_id", ['user_id' => $user_id]);
} catch (Exception $e) {
    die("Erro ao buscar dados: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="rede social para produtos agrícolas">
    <meta name="autor" content="Clinton">
    <title>Rede Social Agrícola</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="/ProjectoAP//assets//Bootstrap//bootstrap.min.css">
    <link rel="stylesheet" href="style.css?v=1.0">
    <link rel="stylesheet" href="/ProjectoAP//assets//all.min.css">

    <style>


    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="row">

            <!-- Barra de Navegação ------------------------------------------------------------------------------------------------------------------------------------------------------------------------>
            <nav class="navbar navbar-expand-sm navbar-light ">
                <div class="container-fluid">
                    <a class="navbar-brand" href="#">
                        <img src="/ProjectoAP//icons//ACEAGRARIOS25.png" alt="Logo" width="60" height="40" class="d-inline-block align-top">ACEAGRARIOS
                    </a>
                    <!--<h5 class="ac" style="color: #ffff;">ACEAGRARIOS</h5>-->
                    <button class="btn btn-light dropdown-toggle " type="button" style="color: #ffff;" data-bs-toggle="dropdown" aria-expanded="false">
                        <?php echo htmlspecialchars($user['nome']); ?>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="logout.php">Sair</a></li>
                    </ul>
                </div>
            </nav>
            <!------------------------------------------------------------------------------------------------------------------------------------------>

            <!-- Frame 1 --------------------------------------------------------------------------------------------------------------------------------->
            <div class="col-3 sticky-frame ">
                <div class="frame-1">
                    <!-------menu orizontal------------------------------------------------------------------------------------------------------------>
                    <ul class="nav nav-tabs">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="#" id="menu-button">Menu</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" id="search-button">Pesquisa</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#" id="produtos-button">Produtos</a>
                        </li>

                    </ul>

                    <!----------------------------------------------------------------------------------------------------------------------------------------->

                    <!-- Área do Menu vertical --------------------------------------------------------------------------------------------------------->
                    <div id="menu-area">
                        <a href="#" class="btn btn-light  w-100 mt-2" id="feed-btn">
                            <i class="fas fa-home"></i> Feed
                        </a>
                        <a href="#" class="btn btn-light w-100 mt-2" id="publicar-btn">
                            <i class="fas fa-pencil-alt"></i> Publicar
                        </a>
                        <a href="#" class="btn btn-light w-100 mt-2" id="chat-btn">
                            <i class="fas fa-comments"></i> Conversas
                        </a>
                        <a href="#" class="btn btn-light w-100 mt-2" id="definicoes-btn">
                            <i class="fas fa-cogs"></i> Perfil
                        </a>
                        <a href="#" class="btn btn-light w-100 mt-2" id="ajuda-btn">
                            <i class="fas fa-question-circle"></i> Ajuda
                        </a>
                    </div>
                    <!---------------------------------------------------------------------------------------------------------------------------------------------->

                    <!-- Área de Pesquisa ---------------------------------------------------------------------------------------------------------------------------->
                    <div id="search-area">
                        <form id="form-pesquisa" onsubmit="return false;" style="display: flex;">
                            <div class="mb-3">
                                <input type="text" id="input-pesquisa" class="form-control" placeholder="Digite sua pesquisa">
                            </div>
                            <div style="margin-left: 10px;">
                            <button type="button" class="btn btn-primary" onclick="realizarPesquisa()">Buscar</button>
                            </div>
                        </form>
                        <div class="horizontal-separator"></div>

                        <!-- Resultados de pesquisa -->
                        <div class="resultados">
                            
                        </div>
                    </div>

                    <!----------------------------------------------------------------------------------------------------------------------------------------------->

                    <!----area de produtos----------------------------------------------------------------------------------------------------------------------------------->
                    <div id="produtos-area">
                        <div class="produtos-area">
                            <button type="button" class="btn btn-sm btn-secondary" id="gerir-btn" style="margin-bottom: 10px;  width: 100%;">+ Criar Produto</button>
                            <div class="orizontal-separator"></div>
                            <div class="produtos">
                                <i class="fas fa-question-circle"></i> Produtos
                            </div>
                        </div>
                    </div>
                    <!-------------------------------------------------------------------------------------------------------------------------------------------------------->

                </div>
            </div>
            <!--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->



            <!-- Frame 2------------------------------------------------------------------------------------------->
            <div class="col-6  ">
                <div class="frame-2 scrollable-frame">
                    <!--------feed-------------------------------------------------------------------------------------->
                    <div id="feed">
                        <div class="feed">
                            <?php foreach ($publicacoes as $publicacao): ?>
                                <div class="card mb-3" style="border-radius: 10px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);">
                                    <div class="card-body">
                                        <!-- Autor e data -->
                                        <div class="foto-perfil d-flex align-items-center mb-3">
                                            <!-- Verifica se o usuário tem uma foto de perfil definida -->
                                            <img src="<?= !empty($publicacao['foto_perfil']) ? $publicacao['foto_perfil'] : 'path-to-default-avatar.jpg'; ?>"
                                                class="rounded-circle"
                                                alt="Avatar"
                                                width="70"
                                                height="70">
                                            <div class="ms-3">
                                                <h6 class="mb-0"><?php echo htmlspecialchars($publicacao['autor']); ?></h6>
                                                <small class="text-muted"><?= date('d M, Y', strtotime($publicacao['data_criacao'])); ?></small>
                                            </div>
                                        </div>


                                        <!-- Conteúdo da publicação -->
                                        <p class="card-text"><?php echo htmlspecialchars($publicacao['conteudo']); ?></p>

                                        <!-- Exibir imagens/vídeos -->
                                        <?php if (!empty($publicacao['media_urls'])): // Verifica se media_urls existe e não está vazio 
                                        ?>
                                            <div class="media-content mb-3" style="margin-top: 10px; margin-bottom: 10px ;">
                                                <?php
                                                foreach (explode(',', $publicacao['media_urls']) as $media_url):
                                                    if (strpos($media_url, '.mp4') !== false): ?>
                                                        <video width="100%" height="auto" controls>
                                                            <source src="<?php echo $media_url; ?>" type="video/mp4">
                                                            Your browser does not support the video tag.
                                                        </video>
                                                    <?php else: ?>
                                                        <img src="<?php echo $media_url; ?>" class="img-fluid rounded mb-2" alt="Imagem da publicação" style="max-width: 100%; height: auto; border-radius: 5px; display: block ;">
                                                <?php endif;
                                                endforeach;
                                                ?>
                                            </div>
                                        <?php endif; ?>

                                        <!-- Botões de interação -->
                                        <div class="d-flex justify-content-around">
                                            <button type="button" class="btn btn-light btn-sm"><i class="fas fa-thumbs-up"></i> Gostei</button>
                                            <button type="button" class="btn btn-light btn-sm"><i class="fas fa-comment"></i> Comentar</button>
                                            <button type="button" class="btn btn-light btn-sm"><i class="fas fa-details"></i> Mais detalhes</button>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>

                        </div>
                    </div>
                    <!-------------------------------------------------------------------------------------------------------->

                    <!-------------------Tela publicar------------------------------------------------------------------------------------->
                    <div id="publicar">
                        <div class="publicar">
                            <form method="POST" action="" enctype="multipart/form-data">
                                <div class="mb-3">
                                    <label for="conteudo" class="form-label">Conteúdo</label>
                                    <textarea class="form-control" id="conteudo" name="conteudo" rows="3" placeholder="Escreva o conteúdo aqui..."></textarea>
                                </div>
                                <div class="mb-3">
                                    <label for="midia" class="form-label">Anexar Imagem/Vídeo</label>
                                    <input type="file" class="form-control" id="midia" name="midia[]" accept="image/*,video/*" multiple>
                                </div>
                                <button type="submit" name="publicar" class="btn btn-primary">Publicar</button>
                            </form>
                        </div>
                    </div>

                    <!---------------------------------------------------------------------------------------------------------------->

                    <!-----Tela Conversas-------------------------------------------------------------------------------------------->
                    <div id="conversas">
                        <div class="conversas">
                            <label class="form-label">
                                <h4><i class="fas fa-comments"></i> Conversas</h4>
                            </label>

                            <form>
                                <div class="mb-3">
                                    <input type="text" class="form-control" placeholder="Pesquise por conversas ou pessoas">
                                </div>
                                <button type="submit" class="btn btn-primary">Pesquisar</button>
                            </form>
                            <hr>

                            <div id="lista-usuarios">
                                <?php if ($conversas): ?>
                                    
                                            <button type="button" class="btn btn-sm btn-secundary" data-bs-toggle="modal" data-bs-target="#userListModal" style="align-items: center; margin-top:10px;">+</button>
                                        
                                    <?php foreach ($conversas as $conversa): ?>
                                        
                                        <a href="#" class="btn btn-light w-100 mt-2" onclick="abrirChat('<?php echo htmlspecialchars($conversa['id']); ?>')">
                                            <i class="fas fa-user"></i> <?php echo htmlspecialchars($conversa['nome']); ?>
                                        </a>
                                        

                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <p>Você ainda não iniciou nenhuma conversa.</p>
                                    <button type="button" class="btn btn-sm btn-secondary" data-bs-toggle="modal" data-bs-target="#userListModal">Iniciar</button>
                                <?php endif; ?>
                            </div>

                            <!-- Modal para a lista de usuários -->
                            <div class="modal fade" id="userListModal" tabindex="-1" aria-labelledby="userListModalLabel" aria-hidden="true">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="userListModalLabel">Selecione um Usuário</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div id="lista-usuarios">
                                                <?php if ($usuarios): ?>
                                                    <?php foreach ($usuarios as $usuario): ?>


                                                        <? $chatId = $usuario['id']; ?>

                                                        <input type="hidden" name="usuario_id" value="?php echo $usuario['id']; ?>">
                                                        <!-- Botão de cada usuário na lista de conversas com o ID do usuário embutido -->
                                                        <button class="btn btn-light w-100 mt-2" onclick="abrirChat(<?php echo htmlspecialchars($usuario['id']); ?>)">
                                                            <?php echo htmlspecialchars($usuario['nome']); ?>
                                                        </button>



                                                    <?php endforeach; ?>
                                                <?php else: ?>
                                                    <p>Nenhum usuário encontrado.</p>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>

                    <!-------------------------------------------------------------------------------------------------------------------->


                    <!----Tela perfil--------------------------------------------------------------------------------------->
                    <div id="definicoes">
                        <div class="definicoes">
                            <label class="form-label">

                                <div class="d-flex align-items-center profile-container">
                                    <!-- Foto de Perfil -->
                                    <div class="profile-picture-wrapper">
                                        <div class="profile-picture-container">
                                            <img src="<?php echo htmlspecialchars($user['foto_perfil']); ?>" alt="Foto de Perfil" class="profile-picture">
                                            <button class="btn btn-sm btn-primary change-photo-btn">Alterar Foto</button>
                                        </div>
                                    </div>
                                    <!-- Nome do Usuário -->
                                    <div class="nome" style="margin-bottom: 60px; margin-left: 10px;">
                                        <h4 class="user-name"><?php echo htmlspecialchars($user['nome']); ?></h4>

                                    </div>
                                </div>
                            </label>

                            <div class="orizontal-separator"></div>

                            <!-- Botão que abre o modal -->
                            <div class="botoes-especiais">
                                <button type="button" class="btn btn-sm btn-secondary" data-bs-toggle="modal" data-bs-target="#resetPasswordModal">
                                    Editar Perfil
                                </button>
                                <button type="button" class="btn btn-sm btn-secondary" id="gerirprod-btn">Gerir produtos</button>
                                <button type="button" class="btn btn-sm btn-secondary" id="mens-btn">Mensagens</button>
                                <button type="button" class="btn btn-sm btn-secondary">Tema</button>
                            </div>
                            <div class="orizontal-separator"></div>

                            <!-- Adicionar publicações do usuário -->
                            <div class="user-publications">
                                <h5>Minhas Publicações</h5>
                                <?php
                                // Buscar publicações do usuário
                                $user_publicacoes = $query->select("SELECT * FROM publicacoes WHERE user_id = :user_id ORDER BY data_criacao DESC", ['user_id' => $user_id]);
                                if ($user_publicacoes):
                                    foreach ($user_publicacoes as $publicacao):
                                ?>
                                        <div class="card mb-3">
                                            <div class="card-body">
                                                <p class="card-text"><?php echo htmlspecialchars($publicacao['conteudo']); ?></p>
                                                <?php if ($publicacao['media_urls']): ?>
                                                    <div class="media-content">
                                                        <?php foreach (explode(',', $publicacao['media_urls']) as $media_url): ?>
                                                            <?php if (strpos($media_url, '.mp4') !== false): ?>
                                                                <video width="100%" height="auto" controls>
                                                                    <source src="<?php echo $media_url; ?>" type="video/mp4">
                                                                    Seu navegador não suporta a tag de vídeo.
                                                                </video>
                                                            <?php else: ?>
                                                                <img src="<?php echo $media_url; ?>" class="img-fluid rounded mb-2" alt="Imagem da publicação">
                                                            <?php endif; ?>
                                                        <?php endforeach; ?>
                                                    </div>
                                                <?php endif; ?>
                                                <a href="#<?php echo $publicacao['id']; ?>" class="btn btn-sm btn-primary">Editar</a>
                                            </div>
                                        </div>
                                    <?php
                                    endforeach;
                                else:
                                    ?>
                                    <p>Você ainda não fez nenhuma publicação.</p>
                                <?php endif; ?>
                            </div>

                        </div>
                    </div>

                    <!---------publicar produtos area--------------------------------------------------------------------------------------------------------------->
                    <div id="publicar_produtos-area">
                        <div class="publicar_produtos-area">
                            publicar/gerir produtos
                            <div class="produto">
                                <div class="product-picture-wrapper" style="border: 1px solid #ddd;">
                                    <div class="product-picture-container">
                                        <img src="" alt="Foto de produto" class="product-picture">
                                    </div>
                                </div>
                                <form action="" style="margin-left: 5px;">
                                    <label for="nomeProduto" class="form-laber">Nome</label>
                                    <input type="text" class="form-control" name="nomeProduto" placeholder="Digite o nome do produto">

                                    <label for="descricao" class="form-laber">Descrição</label>
                                    <input type="text" class="form-control" name="descricao" placeholder="Descreva o produto">
                                </form>
                                <form>
                                    <label for="categoria" class="form-laber">categoria</label>
                                    <input type="text" class="form-control" name="categoria" placeholder="EX: Prod.Alimentar">
                                </form>

                            </div>
                            <div class="orizontal-separator" style="margin-top: 5px;"></div>

                            <div class="quant" style="display:flex;">
                                <form action="">
                                    <label for="ped" class="form-laber">ped.min</label>
                                    <input type="text" class="form-control" name="ped" style="max-width: 50px;">

                                    <label for="quant" class="form-laber">Quant.Disponivel</label>
                                    <input type="text" class="form-control" name="quant" style="max-width: 50px;">
                                </form>
                            </div>

                        </div>
                    </div>

                </div>

                <!-- Modal de redefinir senha -->
                <div class="modal fade" id="resetPasswordModal" tabindex="-1" aria-labelledby="resetPasswordModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="resetPasswordModalLabel">Editar Perfil</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <ul class="nav nav-tabs">
                                    <li class="nav-item">
                                        <a class="nav-link active" aria-current="page" href="#" id="dados-button">Dados do usuario</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="#" id="redefinir-button">Redifinir senha</a>
                                    </li>

                                </ul>
                                <div id="dados-tela">
                                    <div class="dados-tela">
                                        dados
                                    </div>
                                </div>

                                <!-- Formulário para redefinir senha -->
                                <div id="redefinir-tela">
                                    <div class="redefinir-tela">
                                        <form action="redefinir_senha.php" method="POST">
                                            <div class="mb-3">
                                                <label for="currentPassword" class="form-label">Senha Atual</label>
                                                <input type="password" class="form-control" id="currentPassword" name="currentPassword" required>
                                            </div>
                                            <div class="mb-3">
                                                <label for="newPassword" class="form-label">Nova Senha</label>
                                                <input type="password" class="form-control" id="newPassword" name="newPassword" required>
                                            </div>
                                            <div class="mb-3">
                                                <label for="confirmPassword" class="form-label">Confirme a Nova Senha</label>
                                                <input type="password" class="form-control" id="confirmPassword" name="confirmPassword" required>
                                            </div>
                                            <button type="submit" class="btn btn-primary">Redefinir Senha</button>
                                        </form>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!------------------------------------------------------------------------------------------------------------------------------------------------->


                </div>
            </div>
            <!-- Frame 3: Outras Funcionalidades --------------------------------------------------------------------------------------------------------------------------------------------------------------->
            <div class="col-3 sticky-frame ">
                <div class="frame-3">
                    <!---Ajuda-------------------------------------------------------------------------------------------------------------------------------->
                    <div id="ajuda">
                        <div class="ajuda">
                            <label class="form-label">
                                <h4><i class="fas fa-question-circle"></i> Ajuda</h4>
                            </label>

                        </div>
                    </div>
                    <!------------------------------------------------------------------------------------------------------------------->

                    <!--Area do chat---------------------------------------------------------------------------------------------------------->
                    <div id="chat-area" class="chat-container">
                        <div id="chat-navbar" class="chat-navbar">
                            <img id="destinatario-foto" class="user-foto" src="default-avatar.jpg" alt="Foto do Destinatário">
                            <div class="user-info">
                                <h4 id="destinatario-nome">Nome do Destinatário</h4>
                                <p id="destinatario-status">Offline</p>
                            </div>
                        </div>


                        <div id="mensagens" class="mensagens-container">

                            <?php if (!empty($mensagens)): ?>
                                <?php foreach ($mensagens as $mensagem): ?>
                                    <div class="mensagem-balao <?= $mensagem['remetente_id'] == $_SESSION['user_id'] ? 'remetente' : 'destinatario'; ?>">
                                        <p class="conteudo"><?= htmlspecialchars($mensagem['conteudo']); ?></p>
                                        <span class="hora"><?= htmlspecialchars(date('H:i', strtotime($mensagem['data_envio']))); ?></span>
                                    </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <p>Sem mensagens nesta conversa.</p>
                            <?php endif; ?>
                        </div>

                        <!-- Formulário de envio de mensagens -->
                        <form action="enviar_mensagem.php" method="post" class="enviar-mensagem-form">
                            <input type="hidden" name="destinatario_id" value="<?= htmlspecialchars($chatId); ?>">
                            <textarea name="mensagem" class="form-control" placeholder="Digite sua mensagem..."></textarea>
                            <button type="submit" class="btn-enviar"><i class="fas fa-paper-plane"></i></button>
                        </form>
                    </div>

                </div>

                <!----------------------------------------------------------------------------------------------------------------------------------------------->

                <!-------fazer pedido area------------------------------------------------------------------------------------------------------------------------------>
                <div id="pedidos-area">
                    <div class="pedidos-area">
                        fazer pedidos
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------>

    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <script src="/ProjectoAP//assets//Bootstrap//bootstrap.bundle.min.js"></script>

    <script src="/ProjectoAP//Tela inicial//script.js"></script>
</body>

</html>