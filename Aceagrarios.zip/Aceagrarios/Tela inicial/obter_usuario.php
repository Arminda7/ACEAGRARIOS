<?php
session_start();
require_once 'EasyPDO.php'; // Supondo que você tenha um arquivo EasyPDO.php com a classe EasyPDO
use EasyPDO\EasyPDO;
// Verifique se o ID do usuário foi passado via GET
if (isset($_GET['user_id'])) {
    $userId = filter_var($_GET['user_id'], FILTER_VALIDATE_INT);

    if ($userId !== false) {
        try {
            // Conecte-se ao banco de dados usando o EasyPDO
            $db = new EasyPDO();

            // Execute a consulta para obter os dados do usuário
            $usuario = $db->select("SELECT nome, foto, status FROM usuarios WHERE id = :user_id", [
                'user_id' => $userId
            ]);

            // Verifique se o usuário foi encontrado
            if ($usuario) {
                // Como select retorna uma lista de resultados, use $usuario[0] para acessar o primeiro
                echo json_encode([
                    'nome' => $usuario[0]['nome'],
                    'foto' => $usuario[0]['foto'],
                    'status' => $usuario[0]['status'] === '1' ? 'online' : 'offline'
                ]);
            } else {
                echo json_encode(['error' => 'Usuário não encontrado.']);
            }
        } catch (Exception $e) {
            echo json_encode(['error' => 'Erro ao conectar com o banco de dados: ' . $e->getMessage()]);
        }
    } else {
        echo json_encode(['error' => 'ID de usuário inválido.']);
    }
} else {
    echo json_encode(['error' => 'ID de usuário não fornecido.']);
}
?>
