<?php
session_start();
require_once 'EasyPDO.php';
use EasyPDO\EasyPDO;

$userId = $_SESSION['user_id'] ?? null;
$chatId = filter_input(INPUT_GET, 'chat_id', FILTER_VALIDATE_INT);


if (!$userId || !$chatId) {
    echo json_encode(['error' => 'Usuário ou chat não encontrado']);
    exit();
}

try {
    $query = new EasyPDO();
    $mensagens = $query->select("
        SELECT m.conteudo, u.nome AS remetente, m.data_envio
        FROM mensagens m
        JOIN usuarios u ON m.remetente_id = u.id
        WHERE (m.remetente_id = :user_id AND m.destinatario_id = :chat_id)
        OR (m.remetente_id = :chat_id AND m.destinatario_id = :user_id)
        ORDER BY m.data_envio ASC
    ", ['user_id' => $userId, 'chat_id' => $chatId]);

    echo json_encode(['mensagens' => $mensagens]);
} catch (Exception $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>
