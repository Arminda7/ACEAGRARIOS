<!DOCTYPE html>
<html lang="pt">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Redefinir Senha</title>
    <link rel="stylesheet" href="/ProjectoAP//assets//Bootstrap//bootstrap.min.css">
    <link rel="stylesheet" href="style.css?v=1.0">
</head>

<body>
    <div class="container mt-5" style="width: 450px;">
        <div class="card mb-3" style="border-radius: 0px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);">
            <div class="card-body">
                <h2 style="margin-bottom: 20px; text-align: center;">Redefinir Senha</h2>
                <form action="processar_redefinicao.php" method="post">
                    <label for="email" class="form-label">Digite seu e-mail:</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                    <button type="submit" class="btn btn-primary" style="margin-top: 10px;">Enviar</button>
                </form>
            </div>
        </div>
    </div>
</body>

</html>