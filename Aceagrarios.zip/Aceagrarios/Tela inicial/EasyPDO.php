<?php
namespace EasyPDO;

use PDO;

class EasyPDO
{
    // ------------------------------------------------------------------------
    // CONNETION PROPERTIES
    // ------------------------------------------------------------------------
    private $db_host = 'localhost';
    private $db_name = 'aceagrarios';
    private $db_user = 'Clinton';
    private $db_pass = 'zU1NP5[XIUmJ5aK1';
    private $db_char = 'utf8';

    // ------------------------------------------------------------------------
    // CLASS OPTIONS
    // ------------------------------------------------------------------------
    private $opt_display_errors = true;
    private $opt_display_warnings = true;
    private $opt_attr_errmode = PDO::ERRMODE_WARNING;
    private $opt_attr_case = PDO::CASE_NATURAL;
    private $opt_attr_oracle_nulls = PDO::NULL_NATURAL;
    private $opt_debug = true;
    private $opt_fetch_mode = PDO::FETCH_ASSOC; 

    // ------------------------------------------------------------------------
    // CLASS PROPERTIES
    // ------------------------------------------------------------------------
    private $connection;
    private $command;
    public $affectedRows = 0;

    // ========================================================================
    public function __construct(array $options = [])
    {
        $modules = get_loaded_extensions();
        if (!in_array('PDO', $modules) || !in_array('pdo_mysql', $modules)) {
            die('PDO or pdo_mysql modules are not available.');
        }

        if (key_exists('db_host', $options)) $this->db_host = $options['db_host'];
        if (key_exists('db_name', $options)) $this->db_name = $options['db_name'];
        if (key_exists('db_user', $options)) $this->db_user = $options['db_user'];
        if (key_exists('db_pass', $options)) $this->db_pass = $options['db_pass'];
        if (key_exists('db_char', $options)) $this->db_char = $options['db_char'];

        if (empty($this->db_host)) $this->error('Host is empty.');
        if (empty($this->db_name)) $this->error('Database name is empty.');
        if (empty($this->db_user)) $this->error('Username is empty.');
        if (empty($this->db_pass)) $this->warning('Username has no password defined.');
        if (empty($this->db_char)) $this->db_char = 'utf8';

        $str = "mysql:host={$this->db_host};dbname={$this->db_name};charset={$this->db_char}";
        $this->connection = new PDO(
            $str,
            $this->db_user,
            $this->db_pass,
            array(PDO::ATTR_PERSISTENT => true)
        );

        $this->connection->setAttribute(PDO::ATTR_ERRMODE, $this->opt_attr_errmode);
        $this->connection->setAttribute(PDO::ATTR_CASE, $this->opt_attr_case);
        $this->connection->setAttribute(PDO::ATTR_ORACLE_NULLS, $this->opt_attr_oracle_nulls);
    }

    // ========================================================================
    public function select($query, $parameters = null, $class = null)
    {
        if (!preg_match("/^SELECT/i", trim($query))) {
            $this->error('Not a SQL SELECT statement.');
            return null;
        }

        try {
            $command = $this->connection->prepare($query);
            $command->execute($parameters);

            if ($class) {
                if (!class_exists($class)) {
                    $this->error("Class '$class' does not exist.");
                    return null;
                }
                return $command->fetchAll(PDO::FETCH_CLASS, $class);
            }
            return $command->fetchAll($this->opt_fetch_mode);
        } catch (\PDOException $e) {
            $this->error($e->getMessage());
            return null;
        }
    }

    // ========================================================================
    public function insert($query, $parameters = null)
    {
        if (!preg_match("/^INSERT/i", trim($query))) {
            $this->error('Not a SQL INSERT statement.');
            return null;
        }

        try {
            $command = $this->connection->prepare($query);
            $command->execute($parameters);
            $this->affectedRows = $command->rowCount();
        } catch (\PDOException $e) {
            $this->error($e->getMessage());
        }
    }

    // ========================================================================
    // Método para recuperar o último ID inserido
    public function lastInsertId()
    {
        return $this->connection->lastInsertId();
    }

    // ========================================================================
    public function update($query, $parameters = null)
    {
        if (!preg_match("/^UPDATE/i", trim($query))) {
            $this->error('Not a SQL UPDATE statement.');
            return null;
        }

        try {
            $command = $this->connection->prepare($query);
            $command->execute($parameters);
            $this->affectedRows = $command->rowCount();
        } catch (\PDOException $e) {
            $this->error($e->getMessage());
        }
    }

    // ========================================================================
    public function delete($query, $parameters = null)
    {
        if (!preg_match("/^DELETE/i", trim($query))) {
            $this->error('Not a SQL DELETE statement.');
            return null;
        }

        try {
            $command = $this->connection->prepare($query);
            $command->execute($parameters);
            $this->affectedRows = $command->rowCount();
        } catch (\PDOException $e) {
            $this->error($e->getMessage());
        }
    }

    // ========================================================================
    public function query($query, $parameters = null, $class = null)
    {
        if (preg_match("/^SELECT/i", trim($query))) {
            return $this->select($query, $parameters, $class);
        } elseif (preg_match("/^INSERT/i", trim($query))) {
            return $this->insert($query, $parameters);
        } elseif (preg_match("/^UPDATE/i", trim($query))) {
            return $this->update($query, $parameters);
        } elseif (preg_match("/^DELETE/i", trim($query))) {
            return $this->delete($query, $parameters);
        }
    }

    // ========================================================================
    private function warning($message)
    {
        if (!$this->opt_debug) return;
        if (!$this->opt_display_errors) return;
        echo PHP_EOL . "WARNING - $message" . PHP_EOL;
    }

    // ========================================================================
    private function error($message)
    {
        if (!$this->opt_debug) return;
        if (!$this->opt_display_warnings) return;
        die(PHP_EOL . "ERROR - $message" . PHP_EOL);
    }
}
