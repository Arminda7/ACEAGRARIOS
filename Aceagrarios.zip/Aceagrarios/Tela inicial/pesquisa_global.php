<?php
session_start();
header('Content-Type: application/json'); // Garante que a resposta seja JSON
require_once 'EasyPDO.php';

use EasyPDO\EasyPDO;

$response = [];

if (isset($_GET['query']) && !empty($_GET['query'])) {
    $query = trim($_GET['query']);
    try {
        $db = new EasyPDO();

        $resultados = $db->select("SELECT nome, descricao FROM produtos WHERE nome LIKE :query OR descricao LIKE :query LIMIT 10", [
            'query' => '%' . $query . '%'
        ]);

        $response['resultados'] = $resultados;
    } catch (Exception $e) {
        $response['error'] = 'Erro ao conectar ao banco de dados: ' . $e->getMessage();
    }
} else {
    $response['error'] = 'Nenhuma pesquisa fornecida.';
}

echo json_encode($response);
