<?php
session_start();
use EasyPDO\EasyPDO;
require_once 'EasyPDO.php';

$userId = $_SESSION['user_id'] ?? null;
if (!$userId) {
    echo "Erro: Usuário não autenticado.";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $destinatarioId = filter_var($_POST['destinatario_id'], FILTER_VALIDATE_INT);
    $mensagem = trim($_POST['mensagem']);

    if ($destinatarioId !== false && !empty($mensagem)) {
        try {
            $query = new EasyPDO();

            // Insere a nova mensagem
            $query->insert("
                INSERT INTO mensagens (remetente_id, destinatario_id, conteudo, data_envio, lida) 
                VALUES (:remetente_id, :destinatario_id, :conteudo, NOW(), 0)
            ", [
                'remetente_id' => $userId,
                'destinatario_id' => $destinatarioId,
                'conteudo' => $mensagem
            ]);

            // Obtém o ID da última mensagem inserida
            $ultimaMensagemId = $query->lastInsertId();

            // Verifica se a conversa já existe
            $conversa = $query->select("SELECT * FROM conversas WHERE 
                (user1_id = :user1 AND user2_id = :user2) 
                OR (user1_id = :user2 AND user2_id = :user1)
            ", [
                'user1' => $userId,
                'user2' => $destinatarioId
            ]);

            if ($conversa) {
                // Atualiza a última mensagem e data da conversa existente
                $query->update("
                    UPDATE conversas SET ultima_mensagem_id = :ultima_mensagem_id, data_ultima_mensagem = NOW()
                    WHERE id = :conversa_id
                ", [
                    'ultima_mensagem_id' => $ultimaMensagemId,
                    'conversa_id' => $conversa[0]['id']
                ]);
            } else {
                // Cria uma nova conversa se ela não existir
                $query->insert("
                    INSERT INTO conversas (user1_id, user2_id, ultima_mensagem_id, data_ultima_mensagem)
                    VALUES (:user1, :user2, :ultima_mensagem_id, NOW())
                ", [
                    'user1' => $userId,
                    'user2' => $destinatarioId,
                    'ultima_mensagem_id' => $ultimaMensagemId
                ]);
            }

            header("Location: index.php?chat_id=" . $destinatarioId);
            exit();
        } catch (Exception $e) {
            echo "Erro ao enviar mensagem: " . $e->getMessage();
        }
    } else {
        echo "Erro: mensagem ou ID do destinatário não definidos.";
    }
} else {
    echo "Erro: método de solicitação inválido.";
}
