//------pesquisar--------------------------------------------------------------------------------------------------------
document.getElementById('search-button').addEventListener('click', function () {

    document.getElementById('search-area').style.display = 'block';
    document.getElementById('produtos-area').style.display = 'none';
    document.getElementById('menu-area').style.display = 'none';

    // Atualiza as classes para refletir o botão ativo
    document.getElementById('search-button').classList.add('active');
    document.getElementById('menu-button').classList.remove('active');
    document.getElementById('produtos-button').classList.remove('active');

});

//-----menu-----------------------------------------------------------------------------------------------------------
document.getElementById('menu-button').addEventListener('click', function () {

    document.getElementById('menu-area').style.display = 'flex';
    document.getElementById('search-area').style.display = 'none';
    document.getElementById('produtos-area').style.display = 'none';

    // Atualiza as classes para refletir o botão ativo
    document.getElementById('menu-button').classList.add('active');
    document.getElementById('search-button').classList.remove('active');
    document.getElementById('produtos-button').classList.remove('active');
});

//-----produtos-------------------------------------------------------------------------------------------------------
document.getElementById('produtos-button').addEventListener('click', function () {
    document.getElementById('produtos-area').style.display = 'block';
    document.getElementById('search-area').style.display = 'none';
    document.getElementById('menu-area').style.display = 'none';

    // Atualiza as classes para refletir o botão ativo
    document.getElementById('produtos-button').classList.add('active');
    document.getElementById('search-button').classList.remove('active');
    document.getElementById('menu-button').classList.remove('active');
});


//-----feed------------------------------------------------------------------------------------------------------------
document.getElementById('feed-btn').addEventListener('click', function () {
    document.getElementById('feed').style.display = 'flex';
    document.getElementById('publicar').style.display = 'none';
    document.getElementById('definicoes').style.display = 'none';
    document.getElementById('conversas').style.display = 'none';
    document.getElementById('publicar_produtos-area').style.display = 'none';
});

//-----publicar--------------------------------------------------------------------------------------------------------
document.getElementById('publicar-btn').addEventListener('click', function () {
    document.getElementById('publicar').style.display = 'flex';
    document.getElementById('feed').style.display = 'none';
    document.getElementById('conversas').style.display = 'none';
    document.getElementById('definicoes').style.display = 'none';
    document.getElementById('publicar_produtos-area').style.display = 'none';

});

//----chat----------------------------------------------------------------------------------------------------------------
document.getElementById('chat-btn').addEventListener('click', function () {
    document.getElementById('conversas').style.display = 'block';
    document.getElementById('feed').style.display = 'none';
    document.getElementById('publicar').style.display = 'none';
    document.getElementById('definicoes').style.display = 'none';
    document.getElementById('publicar_produtos-area').style.display = 'none';
});
//----botao chat perfil-----------------------------------------------------------------------------------------------
document.getElementById('mens-btn').addEventListener('click', function () {
    document.getElementById('conversas').style.display = 'block';
    document.getElementById('definicoes').style.display = 'none';
    document.getElementById('feed').style.display = 'none';
    document.getElementById('publicar').style.display = 'none';
    document.getElementById('publicar_produtos-area').style.display = 'none';
});

//----Definicoes------------------------------------------------------------------------------------------------------
document.getElementById('definicoes-btn').addEventListener('click', function () {
    document.getElementById('definicoes').style.display = 'flex';
    document.getElementById('feed').style.display = 'none';
    document.getElementById('publicar').style.display = 'none';
    document.getElementById('conversas').style.display = 'none';
    document.getElementById('publicar_produtos-area').style.display = 'none';


});
//-----ajuda------------------------------------------------------------------------------------------------------------
document.getElementById('ajuda-btn').addEventListener('click', function () {
    document.getElementById('ajuda').style.display = 'flex';
    document.getElementById('chat-area').style.display = 'none';
});

//-----pedidos--------------------------------------------------------------------------------------------------------
document.getElementById('gerir-btn').addEventListener('click', function () {
    document.getElementById('publicar_produtos-area').style.display = 'flex';
    document.getElementById('feed').style.display = 'none';
    document.getElementById('publicar').style.display = 'none';
    document.getElementById('conversas').style.display = 'none';
    document.getElementById('definicoes').style.display = 'none';
});
document.getElementById('gerirprod-btn').addEventListener('click', function () {
    document.getElementById('publicar_produtos-area').style.display = 'flex';
    document.getElementById('feed').style.display = 'none';
    document.getElementById('publicar').style.display = 'none';
    document.getElementById('conversas').style.display = 'none';
    document.getElementById('definicoes').style.display = 'none';
});

//---abrir chat-------------------------------------------------------------------------------------------------------------
function abrirChat(destinatarioId) {
    
    // Mostra a área do chat e oculta outras seções
    document.getElementById('chat-area').style.display = 'flex';
    document.getElementById('ajuda').style.display = 'none';

    // Armazena o ID do destinatário em um campo oculto no formulário de envio
    document.querySelector('input[name="destinatario_id"]').value = destinatarioId;
    carregarUsuario(destinatarioId);

    // Realiza uma requisição AJAX para carregar as mensagens
    fetch(`carregar_mensagens.php?chat_id=${destinatarioId}`)
        .then(response => response.json())
        .then(data => {
            const mensagensDiv = document.getElementById('mensagens');
            mensagensDiv.innerHTML = ''; // Limpa mensagens anteriores

            // Adiciona cada mensagem no chat
            data.mensagens.forEach(mensagem => {
                const msgElement = document.createElement('p');
                msgElement.innerHTML = `<strong>${mensagem.remetente}:</strong> ${mensagem.conteudo} <br><small>${mensagem.data_envio}</small>`;
                mensagensDiv.appendChild(msgElement);
            });
        })
        .catch(error => {
            console.error('Erro ao carregar mensagens:', error);
        });
        
}


//-----editar user---------------------------------------------------------------------------------------------------------
//dados------------------------------------------------------------------------------------------
document.getElementById('dados-button').addEventListener('click', function () {
    document.getElementById('dados-tela').style.display = 'block';
    document.getElementById('redefinir-tela').style.display = 'none';


    // Atualiza as classes para refletir o botão ativo
    document.getElementById('dados-button').classList.add('active');
    document.getElementById('redefinir-button').classList.remove('active');

});
//redefinir-----------------------------------------------------------------------------------
document.getElementById('redefinir-button').addEventListener('click', function () {
    document.getElementById('redefinir-tela').style.display = 'block';
    document.getElementById('dados-tela').style.display = 'none';


    // Atualiza as classes para refletir o botão ativo
    document.getElementById('redefinir-button').classList.add('active');
    document.getElementById('dados-button').classList.remove('active');

});

function carregarUsuario(destinatarioId) {
    fetch(`obter_usuario.php?user_id=${destinatarioId}`)
        .then(response => response.json())
        .then(data => {
            if (!data.error) {
                document.getElementById('destinatario-nome').textContent = data.nome;
                document.getElementById('destinatario-status').textContent = data.status;
                document.getElementById('destinatario-foto').src = data.foto;
            } else {
                console.error(data.error);
            }
        })
        .catch(error => console.error('Erro ao carregar usuário:', error));
}
// Suponha que chatId seja o ID do destinatário



// Exemplo de chamada ao abrir o chat

function realizarPesquisa() {
    const termoPesquisa = document.getElementById('input-pesquisa').value;

    if (termoPesquisa.trim() === "") {
        alert("Digite algo para pesquisar.");
        return;
    }

    fetch(`pesquisa_global.php?query=${encodeURIComponent(termoPesquisa)}`)
        .then(response => {
            if (!response.ok) throw new Error('Erro ao realizar pesquisa.');
            return response.json();
        })
        .then(data => {
            const resultadosDiv = document.querySelector('.resultados');
            resultadosDiv.innerHTML = ''; // Limpa resultados anteriores

            if (data.error) {
                resultadosDiv.innerHTML = `<p>${data.error}</p>`;
            } else if (data.resultados && data.resultados.length > 0) {
                data.resultados.forEach(item => {
                    const resultadoItem = document.createElement('div');
                    resultadoItem.classList.add('resultado-item');
                    resultadoItem.innerHTML = `<strong>${item.nome}</strong><p>${item.descricao}</p>`;
                    resultadosDiv.appendChild(resultadoItem);
                });
            } else {
                resultadosDiv.innerHTML = "<p>Nenhum resultado encontrado.</p>";
            }
        })
        .catch(error => {
            console.error('Erro ao realizar pesquisa:', error);
            document.querySelector('.resultados').innerHTML = "<p>Erro ao realizar pesquisa.</p>";
        });
}
