<?php
require_once 'EasyPDO.php';

try {
    $stmt = $pdo->prepare("SELECT id, nome, foto FROM usuarios LIMIT 10");
    $stmt->execute();
    $usuarios = $stmt->fetchAll();

    header('Content-Type: application/json');
    echo json_encode($usuarios);
} catch (PDOException $e) {
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode(['error' => 'Erro ao buscar usuários: ' . $e->getMessage()]);
}
