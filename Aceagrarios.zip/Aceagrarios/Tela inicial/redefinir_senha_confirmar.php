<?php
require 'EasyPDO.php';

use EasyPDO\EasyPDO; 

// Conectar ao banco de dados usando EasyPDO
$dbConfig = [
    'db_host' => 'localhost',
    'db_name' => 'aceagrarios',
    'db_user' => 'Clinton',
    'db_pass' => 'zU1NP5[XIUmJ5aK1'
];

$pdo = new EasyPDO($dbConfig);

if (isset($_GET['token'])) {
    $token = $_GET['token'];

    // Verificar se o token é válido e não expirou
    $usuario = $pdo->select(
        "SELECT * FROM usuarios WHERE token_redefinicao = :token AND token_expiracao > NOW()",
        ['token' => $token]
    );

    if ($usuario) {
        $usuario = $usuario[0]; // Obter o primeiro usuário retornado

        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $novaSenha = password_hash($_POST['nova_senha'], PASSWORD_BCRYPT);

            // Atualizar a senha no banco de dados
            $pdo->update(
                "UPDATE usuarios SET senha = :senha, token_redefinicao = NULL, token_expiracao = NULL WHERE id = :id",
                ['senha' => $novaSenha, 'id' => $usuario['id']]
            );

            echo "Senha redefinida com sucesso!";
        }
    } else {
        echo "Token inválido ou expirado.";
    }
} else {
    echo "Token não fornecido.";
}
?>
