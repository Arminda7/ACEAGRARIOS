<?php
// Conectar ao banco de dados
require_once 'EasyPDO.php';

use EasyPDO\EasyPDO;

$dbConfig = [
    'db_host' => 'localhost',
    'db_name' => 'aceagrarios',
    'db_user' => 'Clinton',
    'db_pass' => 'zU1NP5[XIUmJ5aK1'
];

$pdo = new EasyPDO($dbConfig);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];

    // Verificar se o e-mail existe no banco de dados
    $usuario = $pdo->select("SELECT * FROM usuarios WHERE email = :email", ['email' => $email]);

    if (!empty($usuario)) {
        // Gerar um token de redefinição de senha
        $token = bin2hex(random_bytes(50));

        // Armazenar o token no banco de dados com um tempo de expiração
        $pdo->update(
            "UPDATE usuarios SET token_redefinicao = :token, token_expiracao = DATE_ADD(NOW(), INTERVAL 1 HOUR) WHERE email = :email",
            [
                'token' => $token,
                'email' => $email
            ]
        );

        // Enviar e-mail com o link de redefinição de senha
        $link = "http://seusite.com/redefinir_senha_confirmar.php?token=$token";
        $mensagem = "Clique no link para redefinir sua senha: $link";
        mail($email, "Redefinição de Senha", $mensagem);

        echo "Um e-mail foi enviado para $email com instruções para redefinir sua senha.";
    } else {
        echo "E-mail não encontrado.";
    }
}
?>
