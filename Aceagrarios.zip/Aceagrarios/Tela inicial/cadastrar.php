<?php
session_start();
require_once 'EasyPDO.php';

use EasyPDO\EasyPDO;

$options = [
    'db_host' => 'localhost',
    'db_name' => 'aceagrarios',
    'db_user' => 'Clinton',
    'db_pass' => 'zU1NP5[XIUmJ5aK1'
];

$query = new EasyPDO($options);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = $_POST['senha']; // Sem hash, a senha será salva diretamente

    // Verificar se o e-mail já está cadastrado
    $result = $query->select("SELECT id FROM usuarios WHERE email = :email", ['email' => $email]);

    if (!empty($result)) {
        $error = "Este e-mail já está em uso.";
    } else {
        // Inserir o novo usuário no banco de dados
        $query->insert("INSERT INTO usuarios (nome, email, senha) VALUES (:nome, :email, :senha)", [
            'nome' => $nome,
            'email' => $email,
            'senha' => $senha
        ]);

        
        header("Location: index.php");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Criar Conta - Rede Social Agrícola</title>
    <link rel="stylesheet" href="/ProjectoAP/assets/Bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="style.css?v=1.0">
</head>

<body>
    <div class="container mt-5" style="width: 450px;">
        <div class="card mb-3" style="border-radius: 0px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);">
            <div class="card-body">
                <h2 style="margin-bottom: 20px; text-align: center;">Criar Conta</h2>
                <?php if (isset($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                <form method="POST" action="">
                    <div class="mb-3">
                        <label for="nome" class="form-label">Nome</label>
                        <input type="text" class="form-control" id="nome" name="nome" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="senha" class="form-label">Senha</label>
                        <input type="password" class="form-control" id="senha" name="senha" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Cadastrar</button>
                    <hr>
                    <div>
                        Já tem uma conta? <a href="login.php">Entrar</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>

</html>
