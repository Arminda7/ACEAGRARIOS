<?php
session_start();
require_once 'EasyPDO.php';

use EasyPDO\EasyPDO;

$options = [
    'db_host' => 'localhost',
    'db_name' => 'aceagrarios',
    'db_user' => 'Clinton',
    'db_pass' => 'zU1NP5[XIUmJ5aK1'
];

$query = new EasyPDO($options);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    $result = $query->select("SELECT id FROM usuarios WHERE senha = :senha and email = :email", ['senha' => $senha, 'email' => $email]);

    if (!empty($result)) {
        $user = $result[0];
        #if (password_verify($senha, $user['senha'])) {
        $_SESSION['user_id'] = $user['id'];
        header("Location: index.php");
        exit();
        #} else {
        #$error = "Senha incorreta.";
        #}
    } else {
        $error = "Credenciais incorrectas.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Rede Social Agrícola</title>
    <link rel="stylesheet" href="/ProjectoAP//assets//Bootstrap//bootstrap.min.css">
    <link rel="stylesheet" href="style.css?v=1.0">
</head>

<body>
    <div class="container mt-5" style="width: 450px;">
        <div class="card mb-3" style="border-radius: 0px; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);">
            <div class="card-body">
                <h2 style="margin-bottom: 20px; text-align: center;">Login</h2>
                <?php if (isset($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                <form method="POST" action="">
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="senha" class="form-label">Senha</label>
                        <input type="password" class="form-control" id="senha" name="senha" required>
                    </div>
                    <button type="submit" class="btn btn-primary">Entrar</button>

                    <div class="recuperar" style="margin-top: 10px;">
                        Esqueceu a senha? <a href="redefinir_senha.php">Recuperer</a>
                    </div>
                    <hr>
                    <div>
                        Nao tem uma conta. <a href="cadastrar.php">Cadastrar</a>
                    </div>

                </form>
            </div>
        </div>
    </div>
</body>

</html>